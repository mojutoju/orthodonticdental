<?php
/* english lang
If you translate this on your new language, translate all between brackets ( " text " ), all other you must leave untached.
*/
$BLang_delete = "Delete";
$BLang_create= "Create";
$BLang_save= "Save";
$BLang_filename="File";
$BLang_fullPath="Full Path";
$BLang_permission="Ch.Permission";
$BLang_move_dir= "Move Dir";
$BLang_rename= "Rename";
$BLang_query= "Query";
$BLang_query_prepare= "Start Query";
?>
